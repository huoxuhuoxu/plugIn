

// 得到一个jqxhr对象
var R = $.ajax({
    url: "/shakemoney/api_shake",
    type: "POST",
    cache: false,
    dataType: "json",
    timeout: 10000,
    data: {
        iBeaconIds: v,
        latlng: i,
        networkType: l,
        k: p,
        realId: "662826146735329280"
    }
});


// 成功失败的处理
R.done(function(X) {
	if (X.success) {
	    var U = e.$wrap;
	    var Y = c.$wrap;
	    var W = X.data.award;
	    var T = X.data.ad;
	    if (deviceIsOwner) {
	        U.find(".dia-prize-owner").show()
	    } else {
	        U.find(".dia-prize-owner").hide()
	    }
	    U.find(".app-adwrap").html('<a href="' + T.link + '"><img src="' + T.imageUrl + '" alt=""><span class="app-ad-view">查看详情&gt;</span></a>');
	    if (!W.isNull) {
	        if (W.awardType === 1) {
	            U.find(".mui-avatar-img").attr("src", T.advertiserAvatarUrl);
	            U.find(".prize-txt").text(T.advertiserName + "派送的红包");
	            U.find(".prize-number").text(W.redPacket.giftAmount);
	            U.find(".prize-redpacket-wrap").show();
	            U.find(".j-haslottery-prize").hide();
	            U.find(".j-nolottery-prize").hide();
	            if (W.redPacket.code === 1) {
	                U.find(".prize-sub-txt").hide()
	            } else {
	                U.find(".prize-sub-txt").show()
	            }
	        } else {
	            if (W.awardType === 2) {
	                U.find(".j-haslottery-prize").show();
	                U.find(".prize-redpacket-wrap").hide();
	                U.find(".j-nolottery-prize").hide();
	                U.find(".j-prize-lottery-outofdate").text(W.lottery.betDeadline)
	            } else {
	                if (W.awardType === 3) {
	                    var S = W.wechatFollow;
	                    Y.find(".j-authorizer-img").attr("src", S.imgUrl);
	                    Y.find(".mui-avatar-img").attr("src", S.followerAvatarUrl);
	                    Y.find(".prize-txt").text(S.officialAccounts + " 派发");
	                    Y.find(".prize-number").text(S.price);
	                    Y.find(".j-authorizer-link").attr("href", "/shakemoney/follow/followinfo?deviceid=" + S.deviceId + "&followid=" + S.followId + "&authorizeappid=" + S.authorizeAppId + "&officialaccounts=" + encodeURIComponent(S.officialAccounts) + "&price=" + S.price + "&followeravatarurl=" + S.followerAvatarUrl + "&serviceType=" + S.serviceType)
	                }
	            }
	        }
	    } else {
	        U.find(".j-haslottery-prize").hide();
	        U.find(".prize-redpacket-wrap").hide();
	        U.find(".j-nolottery-prize").show();
	        U.find(".j-nolottery-txt").text(s())
	    }
	    setTimeout(function() {
	        if (!W.isNull) {
	            f.play()
	        } else {
	            B.play()
	        }
	        if (typeof WeixinJSBridge == "object" && typeof WeixinJSBridge.invoke == "function") {
	            WeixinJSBridge.invoke("getNetworkType", {}, function(Z) {
	                if (!W.isNull) {
	                    f.play()
	                } else {
	                    B.play()
	                }
	            })
	        }
	        j.removeClass("shake");
	        if (W.awardType === 3) {
	            c.open()
	        } else {
	            e.open()
	        }
	        x = X.data.remainingShakeCount;
	        d.find(".j-shake-num").text(x)
	    }, 1000)
	} else {
	    if (X.errorCode === 118 || X.errorCode === 204) {
	        m.find("a.dia-prize-btn").attr("href", X.data.verifyMobileUrl);
	        setTimeout(function() {
	            j.removeClass("shake");
	            w.open()
	        }, 1000)
	    } else {
	        var V = new Dialog({
	            content: $("#dia-prize-error"),
	            maskOpacity: 0.3,
	            maskClick: function() {
	                this.close()
	            },
	            afterClose: function() {
	                window.location.reload()
	            }
	        });
	        if (deviceIsOwner) {
	            V.$wrap.find(".dia-prize-owner").show()
	        } else {
	            V.$wrap.find(".dia-prize-owner").hide()
	        }
	        if (X.errorCode === 401) {
	            V.$wrap.find(".prize-error-title").html("今天机会用完了！")
	        } else {
	            V.$wrap.find(".prize-error-title").html("出错啦！")
	        }
	        V.$wrap.find(".prize-error-sub").html(X.msg);
	        V.$wrap.find(".app-adwrap").html('<a href="' + X.data.ad.link + '"><img src="' + X.data.ad.imageUrl + '" alt=""><span class="app-ad-view">查看详情&gt;</span></a>');
	        setTimeout(function() {
	            j.removeClass("shake");
	            V.open()
	        }, 1000)
	    }
	}
	});
	R.fail(function(U, W, V) {
	var S = new Dialog({
	    content: $("#dia-timeout-error"),
	    maskOpacity: 0.3,
	    maskClick: function() {
	        this.close()
	    },
	    afterClose: function() {
	        window.location.reload()
	    }
	});
	u = false;
	if (deviceIsOwner) {
	    S.$wrap.find(".dia-prize-owner").show()
	} else {
	    S.$wrap.find(".dia-prize-owner").hide()
	}
	S.$wrap.find(".prize-error-sub").html("网络不给力，请重新打开页面");
	setTimeout(function() {
	    j.removeClass("shake");
	    S.open()
	}, 1000);
	var T = $.ajax({
	    url: "/shakemoney/debug/api_log",
	    type: "POST",
	    cache: false,
	    dataType: "json",
	    data: {
	        httpCode: U.status,
	        errorThrown: V,
	        textStatus: W,
	        apiUrl: "/shakemoney/api_shake",
	        pageUrl: window.location.href,
	        reqData: "{iBeaconIds: " + v + ",latlng:" + i + ",networkType:" + l + "}",
	        message: encodeURIComponent(U.responseText)
	    }
	})
	})
}



// 猜测是 判定当前网络类型
wx.getNetworkType({
	success: function(R) {
	    l = R.networkType
	}
})


// 包含R/R.done 判断是否处于请求状态,以及 估计是可摇次数 0 跳转
function K() {
	if (!u) {
	    return
	}
	u = false;
	if (x === 0) {
	    window.location.href = "/shakemoney/nochance?ticket=" + ticket;
	    return
	}
	j.addClass("shake");



// 各种外链
e.$wrap.find(".j-myhome-btn").on("click", function(C) {
        if (h === "0") {
            C.preventDefault();
            window.location.href = "/shakemoney/proxy?type=3&ticket=" + ticket
        }
    });
e.$wrap.find(".j-lottery-betting-btn").on("click", function(C) {
        if (h === "0") {
            C.preventDefault();
            window.location.href = "/shakemoney/proxy?type=2&ticket=" + ticket
        }
    });
e.$wrap.find(".j-withdraw-btn").on("click", function(C) {
        if (h === "0") {
            C.preventDefault();
            window.location.href = "/shakemoney/proxy?type=1&ticket=" + ticket
        }
    })




// 样式的处理 以及 请求事件绑定在shake上
var E = $(".shake-page-body");
E.css({
    "background-image": 'url("http://a.f265.com/project/shake-money/img/bg.jpg?t=20160721")'
});
E.find(".shake-con").css({
    "background-image": 'url("http://a.f265.com/project/shake-money/img/shake-bg-min.png")'
});
G.start();
window.addEventListener("shake", K, false);
f = document.getElementById("shakeRightBox");
B = document.getElementById("shakeFailedBox");
f.src = "http://a.f265.com/project/shake-money/img/shake.mp3";
B.src = "http://a.f265.com/project/shake-money/img/shake-failed.mp3";





// 等待k函数回调 执行某些事件
 $.when(k()).done(function() {
    if (h === "0") {
        H.done(function() {
            u = false;
            A.hide();
            t.open()
        })
    } else {
        if (y) {
            if (i.length) {
                C()
            } else {
                setTimeout(function() {
                    C()
                }, 1500)
            }
        } else {
            C()
        }
    }
});


// 搜索周围的beacon 如果成功3500毫秒后执行O,负责关闭延迟定时器，并且进行提示内容在判定...
wx.startSearchBeacons({
        ticket: ticket,
        complete: function(R) {
            J = setTimeout(function() {
                if (D) {
                    O()
                }
            }, 3500);
            if (R.errMsg === "startSearchBeacons:ok") {
                D = true
            } else {
                if (R.errMsg === "startSearchBeacons:location service disable") {
                    D = false;
                    var U = new Dialog({
                        content: $("#dia-GPS-error"),
                        maskOpacity: 0.3,
                        maskClick: function() {
                            this.close()
                        },
                        afterClose: function() {
                            wx.closeWindow()
                        }
                    });
                    U.open();
                    wx.stopSearchBeacons({
                        complete: function(V) {}
                    });
                    clearTimeout(J)
                } else {
                    if (R.errMsg === "startSearchBeacons:bluetooth power off" || R.errMsg === "startSearchBeacons:system unsupported" || R.errMsg === "startSearchBeacons:already started") {
                        var T = new Dialog({
                            content: $("#dia-system-error"),
                            maskOpacity: 0.3,
                            maskClick: function() {
                                this.close()
                            },
                            afterClose: function() {
                                window.location.reload()
                            }
                        });
                        var S = T.$wrap;
                        D = false;
                        T.open();
                        wx.stopSearchBeacons({
                            complete: function(V) {}
                        });
                        clearTimeout(J);
                        S.find(".j-wx-close").on("click", function(V) {
                            V.preventDefault();
                            wx.closeWindow()
                        })
                    }
                }
            }
        }
    })
}



// 摇动事件的封装
(function() {
    function a(b) {
        this.hasDeviceMotion = "ondevicemotion" in window;
        this.options = {
            threshold: 15,
            timeout: 1000
        };
        if (typeof b === "object") {
            for (var c in b) {
                if (b.hasOwnProperty(c)) {
                    this.options[c] = b[c]
                }
            }
        }
        this.lastTime = new Date();
        this.lastX = null;
        this.lastY = null;
        this.lastZ = null;
        if (typeof document.CustomEvent === "function") {
            this.event = new document.CustomEvent("shake", {
                bubbles: true,
                cancelable: true
            })
        } else {
            if (typeof document.createEvent === "function") {
                this.event = document.createEvent("Event");
                this.event.initEvent("shake", true, true)
            } else {
                return false
            }
        }
    }
    a.prototype.reset = function() {
        this.lastTime = new Date();
        this.lastX = null;
        this.lastY = null;
        this.lastZ = null
    };
    a.prototype.start = function() {
        this.reset();
        if (this.hasDeviceMotion) {
            window.addEventListener("devicemotion", this, false)
        }
    };
    a.prototype.stop = function() {
        if (this.hasDeviceMotion) {
            window.removeEventListener("devicemotion", this, false)
        }
        this.reset()
    };
    a.prototype.devicemotion = function(h) {
        var g = h.accelerationIncludingGravity;
        var f;
        var d;
        var c = 0;
        var b = 0;
        var i = 0;
        if ((this.lastX === null) && (this.lastY === null) && (this.lastZ === null)) {
            this.lastX = g.x;
            this.lastY = g.y;
            this.lastZ = g.z;
            return
        }
        c = Math.abs(this.lastX - g.x);
        b = Math.abs(this.lastY - g.y);
        i = Math.abs(this.lastZ - g.z);
        if (((c > this.options.threshold) && (b > this.options.threshold)) || ((c > this.options.threshold) && (i > this.options.threshold)) || ((b > this.options.threshold) && (i > this.options.threshold))) {
            f = new Date();
            d = f.getTime() - this.lastTime.getTime();
            if (d > this.options.timeout) {
                window.dispatchEvent(this.event);
                this.lastTime = new Date()
            }
        }
        this.lastX = g.x;
        this.lastY = g.y;
        this.lastZ = g.z
    };
    a.prototype.handleEvent = function(b) {
        if (typeof(this[b.type]) === "function") {
            return this[b.type](b)
        }
    };
    window.Shake = a
})();





// 无关紧要的样式效果一类
(function(c) {
    var e = c(document),
        a, d;

    function b() {
            var f = a.attr("hl-cls");
            clearTimeout(d);
            a.removeClass(f).removeAttr("hl-cls");
            a = null;
            e.off("touchend touchmove touchcancel", b)
        }
    c.fn.highlight = function(g, f) {
            return this.each(function() {
                var h = c(this);
                h.css("-webkit-tap-highlight-color", "rgba(255,255,255,0)").off("touchstart.hl");
                g && h.on("touchstart.hl", function(j) {
                    var i;
                    a = f ? (i = c(j.target).closest(f, this)) && i.length && i : h;
                    if (a) {
                        a.attr("hl-cls", g);
                        d = setTimeout(function() {
                            a.addClass(g)
                        }, 100);
                        e.on("touchend touchmove touchcancel", b)
                    }
                })
            })
        }
})(jQuery);

(function(c) {
    var b = c.fn.offset,
        a = Math.round;

    function d(e) {
            return this.each(function(g) {
                var h = c(this),
                    i = c.isFunction(e) ? e.call(this, g, h.offset()) : e,
                    f = h.css("position"),
                    j = f === "absolute" || f === "fixed" || h.position();
                if (f === "relative") {
                        j.top -= parseFloat(h.css("top")) || parseFloat(h.css("bottom")) * -1 || 0;
                        j.left -= parseFloat(h.css("left")) || parseFloat(h.css("right")) * -1 || 0
                    }
                parentOffset = h.offsetParent().offset(),
                props = {
                        top: a(i.top - (j.top || 0) - parentOffset.top),
                        left: a(i.left - (j.left || 0) - parentOffset.left)
                    };
                if (f == "static") {
                        props.position = "relative"
                    }
                if (i.using) {
                        i.using.call(this, props, g)
                    } else {
                        h.css(props)
                    }
            })
        }
    c.fn.offset = function(e) {
            return e ? d.call(this, e) : b.call(this)
        }
})(jQuery);

(function(e, a) {
	var g = e.fn.position,
	    k = Math.round,
	    c = /^(left|center|right)([\+\-]\d+%?)?$/,
	    h = /^(top|center|bottom)([\+\-]\d+%?)?$/,
	    b = /%$/;

	function i(n, m) {
	        return (parseInt(n, 10) || 0) * (b.test(n) ? m / 100 : 1)
	    }
	function l(p, o, n, m) {
	        return [p[0] === "right" ? n : p[0] === "center" ? n / 2 : 0, p[1] === "bottom" ? m : p[1] === "center" ? m / 2 : 0, i(o[0], n), i(o[1], m)]
	    }
	function f(n) {
	        var m = n[0],
	            o = m.preventDefault;
	        m = m.touches && m.touches[0] || m;
	        if (m.nodeType === 9 || m === window || o) {
	                return {
	                    width: o ? 0 : n.width(),
	                    height: o ? 0 : n.height(),
	                    top: m.pageYOffset || m.pageY || 0,
	                    left: m.pageXOffset || m.pageX || 0
	                }
	            }
	        return n.offset()
	    }
	function j(n) {
	        var m = e(n = (n || window)),
	            o = f(m);
	        n = m[0];
	        return {
	                $el: m,
	                width: o.width,
	                height: o.height,
	                scrollLeft: n.pageXOffset || n.scrollLeft,
	                scrollTop: n.pageYOffset || n.scrollTop
	            }
	    }
	function d(n, m) {["my", "at"].forEach(function(p) {
	            var r = (n[p] || "").split(" "),
	                o = n[p] = ["center", "center"],
	                q = m[p] = [0, 0];
	            r.length === 1 && r[h.test(r[0]) ? "unshift" : "push"]("center");
	            c.test(r[0]) && (o[0] = RegExp.$1) && (q[0] = RegExp.$2);
	            h.test(r[1]) && (o[1] = RegExp.$1) && (q[1] = RegExp.$2)
	        })
	    }
	e.fn.position = function(o) {
	        if (!o || !o.of) {
	            return g.call(this)
	        }
	        o = e.extend({}, o);
	        var r = e(o.of),
	            t = o.collision,
	            m = t && j(o.within),
	            q = {},
	            p = f(r),
	            s = {
	                left: p.left,
	                top: p.top
	            },
	            n;
	        r[0].preventDefault && (o.at = "left top");
	        d(o, q);
	        n = l(o.at, q.at, p.width, p.height);
	        s.left += n[0] + n[2];
	        s.top += n[1] + n[3];
	        return this.each(function() {
	                var v = e(this),
	                    x = v.offset(),
	                    w = v.width(),
	                    u = v.height(),
	                    z = e.extend({}, s),
	                    y = l(o.my, q.my, w, u);
	                z.left = k(z.left + y[2] - y[0]);
	                z.top = k(z.top + y[3] - y[1]);
	                t && t.call(this, z, {
	                        of: p,
	                        offset: x,
	                        my: o.my,
	                        at: o.at,
	                        within: m,
	                        $el: v
	                    });
	                z.using = o.using;
	                v.offset(z)
	            })
	    }
	})(jQuery);



// 封装了一套dialog弹窗
(function() {
    var c = {
        mask: '<div class="mui-dialog-mask"></div>',
        wrap: '<div class="mui-dialog"><div class="mui-dialog-content"></div></div> '
    };
    var a = function(d) {
        this.initialize("dialog", d)
    };
    a.prototype = {
        constructor: a,
        initialize: function(e, d) {
            this.type = e;
            this.options = this.options || this.getOptions(d);
            var f = this.options,
                g = {};
            this.$container = $(f.container || document.body);
                (this._cIsBody = this.$container.is("body")) || this.$container.addClass("mui-dialog-container");
            this.$mask = f.mask ? $(c.mask).appendTo(this.$container) : null;
            if (f.mask) {
                    if (f.maskOpacity) {
                        this.$mask.css({
                            opacity: f.maskOpacity
                        })
                    }
                }
            this.$wrap = $(c.wrap).appendTo(this.$container);
            this.$wrap.addClass(f.cls);
            f.customCls && this.$wrap.addClass(f.customCls);
            this.$content = $(".mui-dialog-content", this.$wrap);
            this.$el = this.$el || this.$content;
            if (f.content.constructor == jQuery) {
                    f.content.show()
                }
            this.content(f.content);
            this.$wrap.css({
                    width: f.width,
                    height: f.height
                });
            this.bindEvent();
            f.autoOpen && this.open()
        },
        bindEvent: function() {
            var d = this;
            var e = this.options;
            $(window).on("ortchange", function() {
                d.refresh()
            });
            this.$mask && this.$mask.on("click", function(f) {
                if ( !! e.maskClick && (typeof e.maskClick === "function")) {
                    e.maskClick.call(d)
                }
            });
            this.$wrap.on("click", ".mui-dialog-close", function(f) {
                f.preventDefault();
                d.close()
            })
        },
        getOptions: function(d) {
            d = $.extend({}, b, (this.options || {}), d);
            d.position = d.position || {
                of: d.container || window,
                at: "center",
                my: "center"
            };
            return d
        },
        _eventHandler: function(j) {
            var i = this,
                d, g, h = i.options,
                f;
            switch (j.type) {
                case "ortchange":
                    this.refresh();
                    break;
                case "touchmove":
                    h.scrollMove && j.preventDefault();
                    break;
                case "click":
                    if (i.$mask && ($.contains(i.$mask[0], j.target) || i.$mask[0] === j.target)) {
                        return i.trigger("maskClick")
                    }
                }
        },
        _calculateorigin: function() {
            var j = this,
                i = j.options,
                h, k, e = document.body,
                g = {},
                d = this._cIsBody,
                f = Math.round;
            i.mask && (g.mask = d ? {
                    width: "100%",
                    height: Math.max(e.scrollHeight, e.clientHeight) - 1
                } : {
                    width: "100%",
                    height: "100%"
                });
            h = this.$wrap.offset();
            k = $(window);
            g.wrap = {
                    left: "50%",
                    marginLeft: -f(h.width / 2) + i.unit,
                    top: d ? f(k.height() / 2) + window.pageYOffset : "50%",
                    marginTop: -f(h.height / 2) + i.unit
                };
            return g
        },
        _calculate: function() {
            var g = this,
                f = g.options,
                d = f.position,
                e = g._calculateorigin();
            this.$wrap.position($.extend(d, {
                    using: function(h) {
                        e.wrap = h
                    }
                }));
            return e
        },
        refresh: function() {
            var f = this,
                e = f.options,
                d, g;
            if (this._isOpen) {
                    g = function() {
                        d = f._calculate();
                        d.mask && f.$mask.css(d.mask);
                        f.$wrap.css(d.wrap)
                    };
                    if ($.os.ios && document.activeElement && /input|textarea|select/i.test(document.activeElement.tagName)) {
                        document.body.scrollLeft = 0;
                        setTimeout(g, 200)
                    } else {
                        g()
                    }
                }
            return f
        },
        open: function(e) {
            var d = this.options;
            this._isOpen = true;
            $(window).on("touchmove", function(f) {
                d.scrollMove && f.preventDefault()
            });
            this.$wrap.css("display", "block");
            this.$mask && this.$mask.css("display", "block");
            e !== undefined && this.position ? this.position(e) : this.refresh();
            $(document).on("touchmove", $.proxy(this._eventHandler, this))
        },
        close: function() {
            var d = this.options;
            $(window).off("touchmove");
            this._isOpen = false;
            this.$wrap.css("display", "none");
            this.$mask && this.$mask.css("display", "none");
            $(document).off("touchmove", this._eventHandler);
            if ( !! d.afterClose && (typeof d.afterClose === "function")) {
                d.afterClose.call(this)
            }
        },
        position: function(e) {
            var d = this.options;
            d.position = $.extend(d.position, e);
            return this.refresh()
        },
        content: function(e) {
            var d = this.options,
                f = e !== undefined;
            f && this.$content.empty().append(d.content = e);
            return f ? this : d.content
        },
        destroy: function() {
            var d = this.options,
                e = this._eventHandler;
            $(window).off("ortchange", e);
            $(document).off("touchmove", e);
            this.$wrap.off("click", e).remove();
            this.$mask && this.$mask.off("click", e).remove();
            this.$close && this.$close.highlight();
            return this.$super("destroy")
        }
    };
    var b = {
        customCls: "",
        cls: "ui-dialog-empty",
        autoOpen: false,
        buttons: [],
        closeBtn: true,
        mask: true,
        maskOpacity: null,
        width: "100%",
        height: "auto",
        title: null,
        content: null,
        scrollMove: true,
        container: null,
        unit: "px",
        maskClick: null,
        afterClose: null,
        position: null
    };
    window.Dialog = a
})();



// 看不懂 但估计用处不大
<script type="text/javascript">
           
            
            (function(a, b) {
                a.parseTpl = function(f, e) {
                    var c = "var __p=[];with(obj||{}){__p.push('" + f.replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/<%=([\s\S]+?)%>/g, function(g, h) {
                        return "'," + h.replace(/\\'/, "'") + ",'"
                    }).replace(/<%([\s\S]+?)%>/g, function(g, h) {
                        return "');" + h.replace(/\\'/, "'").replace(/[\r\n\t]/g, " ") + "__p.push('"
                    }).replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t") + '\');}return __p.join("");',
                        d = new Function("obj", c);
                    return e ? d(e) : d
                }
            })(jQuery);

        </script>




// 得出当前用户的系统及使用的浏览器环境
(function(b) {
    function a(v) {
        var l = this.os = {},
            w = this.browser = {},
            d = v.match(/Web[kK]it[\/]{0,1}([\d.]+)/),
            x = v.match(/(Android);?[\s\/]+([\d.]+)?/),
            y = !! v.match(/\(Macintosh\; Intel /),
            p = v.match(/(iPad).*OS\s([\d_]+)/),
            j = v.match(/(iPod)(.*OS\s([\d_]+))?/),
            h = !p && v.match(/(iPhone\sOS)\s([\d_]+)/),
            c = v.match(/(webOS|hpwOS)[\s\/]([\d.]+)/),
            f = v.match(/Windows Phone ([\d.]+)/),
            r = c && v.match(/TouchPad/),
            i = v.match(/Kindle\/([\d.]+)/),
            u = v.match(/Silk\/([\d._]+)/),
            q = v.match(/(BlackBerry).*Version\/([\d.]+)/),
            n = v.match(/(BB10).*Version\/([\d.]+)/),
            e = v.match(/(RIM\sTablet\sOS)\s([\d.]+)/),
            o = v.match(/PlayBook/),
            t = v.match(/Chrome\/([\d.]+)/) || v.match(/CriOS\/([\d.]+)/),
            k = v.match(/Firefox\/([\d.]+)/),
            s = v.match(/MSIE\s([\d.]+)/) || v.match(/Trident\/[\d](?=[^\?]+).*rv:([0-9.].)/),
            g = !t && v.match(/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/),
            m = g || v.match(/Version\/([\d.]+)([^S](Safari)|[^M]*(Mobile)[^S]*(Safari))/);
        
        // 根据d是否为真 得出webkit的bool,得到版本号数字部分
        if (w.webkit = !! d) {
                w.version = d[1]
            }
        // 同上 拿到数字部分
        if (x) {
                l.android = true,
                l.version = x[2]
            }
        // iphone
        if (h && !j) {
                l.ios = l.iphone = true,
                l.version = h[2].replace(/_/g, ".")
            }
        // ipad
        if (p) {
                l.ios = l.ipad = true,
                l.version = p[2].replace(/_/g, ".")
            }
        // ipod
        if (j) {
                l.ios = l.ipod = true,
                l.version = j[3] ? j[3].replace(/_/g, ".") : null
            }
        // wp
        if (f) {
                l.wp = true,
                l.version = f[1]
            }
        // webos
        if (c) {
                l.webos = true,
                l.version = c[2]
            }
        // touchpad
        if (r) {
                l.touchpad = true
            }
        // 黑莓
        if (q) {
                l.blackberry = true,
                l.version = q[2]
            }
        // BB10
        if (n) {
                l.bb10 = true,
                l.version = n[2]
            }
        // RIM
        if (e) {
                l.rimtabletos = true,
                l.version = e[2]
            }
        // playbook
        if (o) {
                w.playbook = true
            }
        // kindle
        if (i) {
                l.kindle = true,
                l.version = i[1]
            }
        // silk
        if (u) {
                w.silk = true,
                w.version = u[1]
            }
        if (!u && l.android && v.match(/Kindle Fire/)) {
                w.silk = true
            }
        // chrome
        if (t) {
                w.chrome = true,
                w.version = t[1]
            }
        // firefox
        if (k) {
                w.firefox = true,
                w.version = k[1]
            }
        // MSIE
        if (s) {
                w.ie = true,
                w.version = s[1]
            }
        // safari
        if (m && (y || l.ios)) {
                w.safari = true;
                if (y) {
                    w.version = m[1]
                }
            }
        // AppleWebKit/safari
        if (g) {
                w.webview = true
            }
        // 系统区分
        l.tablet = !! (p || o || (x && !v.match(/Mobile/)) || (k && v.match(/Tablet/)) || (s && !v.match(/Phone/) && v.match(/Touch/)));
        l.phone = !! (!l.tablet && !l.ipod && (x || h || c || q || n || (t && v.match(/Android/)) || (t && v.match(/CriOS\/([\d.]+)/)) || (k && v.match(/Mobile/)) || (s && v.match(/Touch/))))
    }
    a.call(b, navigator.userAgent);
    b.__detect = a
})(jQuery);



内部 放了两个js库 貌似：
jQuery 和 一套webgl库： 已拆出: jQuery2-2-3.js 3d_webgl.js







// 一开始已知值

<script>
    var appId = 'wx301fd77388435637'; // 必填，公众号的唯一标识
    var timestamp = '1476967036'; // 必填，生成签名的时间戳
    var nonceStr = '2cd273dde6b94d7d907d70f9b8cb73a5'; // 必填，生成签名的随机串
    var signature = '0a0a41a19b35da34f1abcc02065fef4d6a8a1fa7'; // 必填，签名，见附录1
    var ticket = '8b63463da71c02ac1cf93acc4fe22d70'; //从微信摇一摇进入时所带的ticket参数
    var deviceIsOwner = false; //摇的人是否是绑定者
    var deviceUuid = 'FDA50693-A4E2-4FB1-AFCF-C6EB07647825';
    var deviceMajor = 10059;
    var deviceMinor = 25808;
    var isFeiWen = false;
    var verifyMobile = false;
</script>



// #k 的值
<input id="k" type="hidden" value="67d50e32707b4b01903156c4e7e24ca0">




逻辑：
b: 判断是否为 Mac OS X 
b = true -> a = #k.value -> storage:K ? true: p=K ::: p = a,stirage:K

b = false ->  new Fingerprint2().get(C){p = "xx"+C} : C ?

每个新用户进来 都会在storage中产生一个k,#k的值. 并且一直存在,之后在怎么进来，k都是第一次的值












