

// 摇一摇 封装处理
(function() {
    function a(b) {
        this.hasDeviceMotion = "ondevicemotion" in window;
        this.options = {
            threshold: 15,
            timeout: 1000
        };
        if (typeof b === "object") {
            for (var c in b) {
                if (b.hasOwnProperty(c)) {
                    this.options[c] = b[c]
                }
            }
        }
        this.lastTime = new Date();
        this.lastX = null;
        this.lastY = null;
        this.lastZ = null;
        if (typeof document.CustomEvent === "function") {
            this.event = new document.CustomEvent("shake", {
                bubbles: true,
                cancelable: true
            })
        } else {
            if (typeof document.createEvent === "function") {
                this.event = document.createEvent("Event");
                this.event.initEvent("shake", true, true)
            } else {
                return false
            }
        }
    }
    a.prototype.reset = function() {
        this.lastTime = new Date();
        this.lastX = null;
        this.lastY = null;
        this.lastZ = null
    };
    a.prototype.start = function() {
        this.reset();
        if (this.hasDeviceMotion) {
            window.addEventListener("devicemotion", this, false)
        }
    };
    a.prototype.stop = function() {
        if (this.hasDeviceMotion) {
            window.removeEventListener("devicemotion", this, false)
        }
        this.reset()
    };
    a.prototype.devicemotion = function(h) {
        var g = h.accelerationIncludingGravity;
        var f;
        var d;
        var c = 0;
        var b = 0;
        var i = 0;
        if ((this.lastX === null) && (this.lastY === null) && (this.lastZ === null)) {
            this.lastX = g.x;
            this.lastY = g.y;
            this.lastZ = g.z;
            return
        }
        c = Math.abs(this.lastX - g.x);
        b = Math.abs(this.lastY - g.y);
        i = Math.abs(this.lastZ - g.z);
        if (((c > this.options.threshold) && (b > this.options.threshold)) || ((c > this.options.threshold) && (i > this.options.threshold)) || ((b > this.options.threshold) && (i > this.options.threshold))) {
            f = new Date();
            d = f.getTime() - this.lastTime.getTime();
            if (d > this.options.timeout) {
                window.dispatchEvent(this.event);
                this.lastTime = new Date()
            }
        }
        this.lastX = g.x;
        this.lastY = g.y;
        this.lastZ = g.z
    };
    a.prototype.handleEvent = function(b) {
        if (typeof(this[b.type]) === "function") {
            return this[b.type](b)
        }
    };
    window.Shake = a
})();





// ??????
function z(E, D) {
    var C;
    return function() {
        if (E) {
            C = E.apply(D || this, arguments);
            E = null
        }
        return C
    }
}


// ??????
var O = z(function() {
    if (verifyMobile) {
        w.open();
        A.hide();
        u = false
    } else {
        A.hide();
        u = true
    }
});














